class Convertor:
    en_to_ru_map = str.maketrans(
        "abvgdeezijklmnoprstufhcyABVGDEEZIJKLMNOPRSTUFHCY",
        "абвгдеезийклмнопрстуфхцыАБВГДЕЕЗИЙКЛМНОПРСТУФХЦЫ"
    )
    
    ru_to_en_map = str.maketrans(
        "абвгдеезийклмнопрстуфхцыАБВГДЕЕЗИЙКЛМНОПРСТУФХЦЫ",
        "abvgdeezijklmnoprstufhcyABVGDEEZIJKLMNOPRSTUFHCY"
    )
    
    def en_to_ru(self, text):
        return text.translate(self.en_to_ru_map)
    
    def ru_to_en(self, text):
        return text.translate(self.ru_to_en_map)

converter = Convertor()
print(converter.en_to_ru("Hello world"))
print(converter.ru_to_en("Привет мир"))
