class Taqvim:
    def hijriyga(self, yil):
        return yil - 622 + (yil - 622) // 33
    
    def grigoriyanga(self, hijriy_yil):
        return hijriy_yil + 622 - (hijriy_yil // 33)
    
    def kabisa(self, yil):
        if yil % 4 == 0 and (yil % 100 != 0 or yil % 400 == 0):
            return True
        return False

taqvim = Taqvim()
print(taqvim.hijriyga(2024))
print(taqvim.grigoriyanga(1446))
print(taqvim.kabisa(2024))
