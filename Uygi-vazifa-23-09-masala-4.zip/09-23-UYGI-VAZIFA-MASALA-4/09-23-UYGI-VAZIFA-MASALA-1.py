class Talaba:
    def __init__(self, name, age):
        self.name = name
        self.age = age
class Kurs:
    def __init__(self, kurs_name, kurs_teacher):
        self.kurs_name = kurs_name
        self.kurs_teacher = kurs_teacher
        self.talabalar_soni = 0
        self.talabalar = []
    def add(self, new_student):
        self.talabalar.append(new_student)
        self.talabalar_soni += 1
        print(f"{new_student.name} kursga qo'shildi.")
    def delete(self, new_student):
        if new_student in self.talabalar:
            self.talabalar.remove(new_student)
            self.talabalar_soni -= 1
            print(f"{new_student.name} kursdan chiqarildi.")
        else:
            print(f"{new_student.name} kursda mavjud emas.")
    def info_kurs(self):
        print(f"Kurs nomi: {self.kurs_name}")
        print(f"Kurs o'qituvchisi: {self.kurs_teacher}")
        print(f"Talabalar soni: {self.talabalar_soni}")
        print("Talabalar:")
        for talaba in self.talabalar:
            print(f"- {talaba.name}, {talaba.age} yosh")
kurs1 = Kurs("Python Dasturlash", "Alisher Isayev")
kurs2 = Kurs("Web Dasturlash", "Nodirbek Usmonov")
for i in range(10):
    talaba = Talaba(f"Talaba {i+1}", 20 + i)
    kurs1.add(talaba)
    kurs2.add(talaba)
kurs1.delete(kurs1.talabalar[0])
kurs1.delete(kurs1.talabalar[1])
kurs2.delete(kurs2.talabalar[0])
kurs2.delete(kurs2.talabalar[1])
kurs1.info_kurs()
kurs2.info_kurs()
