class String:
    def __init__(self, text):
        self.text = text
    
    def to_lower(self):
        result = ''
        for char in self.text:
            if 'A' <= char <= 'Z':
                result += chr(ord(char) + 32)
            else:
                result += char
        return result
    
    def to_upper(self):
        result = ''
        for char in self.text:
            if 'a' <= char <= 'z':
                result += chr(ord(char) - 32)
            else:
                result += char
        return result
    
    def is_lower(self):
        for char in self.text:
            if 'A' <= char <= 'Z':
                return False
        return True
    
    def is_upper(self):
        for char in self.text:
            if 'a' <= char <= 'z':
                return False
        return True

string = String("Hello")
print(string.to_lower())
print(string.to_upper())
print(string.is_lower())
print(string.is_upper())
