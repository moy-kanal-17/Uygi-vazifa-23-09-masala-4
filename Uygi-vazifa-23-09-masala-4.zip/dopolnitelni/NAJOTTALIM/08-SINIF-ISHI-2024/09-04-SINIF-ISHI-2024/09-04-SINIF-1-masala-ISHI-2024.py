ti= (44,True, 'good',3.14)
print(ti[1])
if ti[1]==True:
    print("python yomon dasturlash tili !")