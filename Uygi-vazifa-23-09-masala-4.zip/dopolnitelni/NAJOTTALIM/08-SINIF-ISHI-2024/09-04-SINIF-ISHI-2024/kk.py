list1 = ['AWM', "DON'T GO THE DARK"]
list1 = [element.lower() for element in list1]
print(list1)
