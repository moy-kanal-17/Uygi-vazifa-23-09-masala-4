ist=['aple', 'Amazon', 'meta']
ist.append('Google')
print(ist)
i =['aple', 'Amazon', 'meta']
i.insert(0,'Google')
print(i)
g=['aple', 'Amazon', 'meta']
i.extend( ist)
print(i)
print('ishlavotii!')
b =ist.reverse()
print(b)
ist.sort()
print(ist)
