class MyClass:
    def __init__(self,n,s,a,uu):
        self.name=n
        self.surname=s
        self.aga=a
        self.uroven=uu
    def salom_ber(self,ff):
        print(f"Salom {self.name}")
        if ff<70:
            print("AFSUZ!,SIZ BU BOSQICHTAN OTOLMADINGIZ!, KENGI OYDN BOSHQATAN OQISIZ!")
        elif ff>=70:
            print(f"\n\n\n\n \033[32mtabriklimiz {self.name}! siz Imtixondan otiz!")
            self.uroven=self.uroven+1
            print(f"\n\nsiz yengi urovenga otiz!, uroven={self.uroven}\n\n\n","\033[0m")
a=4
c1=MyClass("Abduqodir", "Faxriddinov",15,5)
c1.salom_ber(100)

