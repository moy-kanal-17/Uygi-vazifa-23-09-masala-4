# Muhim buyruqlar

- **git add .** o'zgarishlarni gitga qo'shish
- **git commit -m "o'zgarish"** o'zgarishlarni izohlash
- **git push** o'zgarishlarni globalga jo'natish
- **git pull** globaldagi o'zgarishlarni localga chaqirish

### Eslatma!
```
Har doim yangi o'zgarishlarni `push` qilishdan avval, `git pull` buyrug'ini yozishni unutmang!
```
