def list_to_dict(keys, values):
    re = {}
    for i in range(len(keys)):
        re[keys[i]] = values[i]
    return re
list1 = ["Jon", "Jeyms", "Piter", "Tony"]
list2 = ["Vik", "Bond", "Parker", "Stark"]
result = list_to_dict(list1, list2)
print(result)
