def musbat(liist):
    mu = []
    for i in liist:
        if i > 0:
            mu.append(i)
    return mu

liist = [1, -1, 2, 9, -3, -11, 20, 5, -8, 4]
o = musbat(liist)
print(o)
